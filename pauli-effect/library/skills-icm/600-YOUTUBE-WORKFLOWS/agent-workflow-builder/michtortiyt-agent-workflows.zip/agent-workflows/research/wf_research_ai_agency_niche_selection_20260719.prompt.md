# AI Agency Niche Selection & Validation System

**Category**: research | **Version**: 1.0.0 | **Source**: @michtortiyt (2 videos)

## Goal
Select and validate ONE AI agency niche within 7 days using the Michele Torti 3-axis scoring framework (deal size × pain intensity × tech-readiness), then confirm with outreach data before committing.

**Success when**:
- One niche selected and scored on all 3 axes
- 5 prospects in niche contacted within 48h of selection
- At least 1 discovery conversation completed to validate pain hypothesis
- Niche locked for 30-day campaign before any pivot considered

**KPIs**:
- niche_score: 7.5 out_of_10
- validation_conversations: 5 count
- pain_confirmation_rate: 60 percent
- days_to_lock_niche: 7 days

## Agents

### Niche Research Orchestrator (orchestrator)
Tools: supabase, bright_data_mcp

### Market Researcher (executor)
Tools: bright_data_mcp, supabase

### Niche Validator (guardian)
Tools: supabase

### Niche Report Writer (reporter)
Tools: supabase, notion

## Task Execution Order

### Task task_01: Score Top 5 Niches
**Agent**: agent_02 | **Depends on**: none | **Timeout**: 180s
Step 1: Score each of the 8 approved niches on 3 axes (1-10 each): (A) deal_size = average value of one client to that business, scaled to fee potential. (B) pain_intensity = how acute is the manual process pain (ask: would they pay $500/mo to fix this without thinking?). (C) tech_readiness = are they open to AI tools (score higher if they already use CRMs, booking software, or digital marketing).
Step 2: Compute composite score: (deal_size × 0.35) + (pain_intensity × 0.40) + (tech_readiness × 0.25).
Step 3: Rank all 8 niches by composite score. Top 3 proceed to validation step.
Step 4: Apply personal fit filter: remove any niche where you have zero connections, zero credibility, and zero case studies to point to.
Step 5: Select top remaining niche. Write selection justification to artifact_01.
**Output**: artifact_01 (json)

### Task task_02: Validate with 5 Prospect Conversations
**Agent**: agent_02 | **Depends on**: ['task_01'] | **Timeout**: 300s
Step 1: Build a list of 5 specific prospects in the chosen niche using LinkedIn. Must be decision-makers (owner, practice manager, broker).
Step 2: Send connection + value DM. NOT a pitch. Frame as market research: 'I'm exploring how [niche] businesses handle [pain area] — would you be open to a 10-min chat? No pitch, just trying to understand the landscape.'
Step 3: In any conversation that books, ask 3 questions: (1) What does your current process look like for [pain area]? (2) How much time/money does this cost you monthly (rough estimate)? (3) Have you tried any tools to solve this?
Step 4: After 5 outreach attempts, score pain_confirmation_rate: % who described the pain point as significant (not 'we're fine').
Step 5: If pain_confirmation_rate < 40%: flag niche for review — pain may not be as acute as scored. Write validation results to artifact_02.
**Output**: artifact_02 (json)

### Task task_03: Guardrail Check & Niche Lock
**Agent**: agent_03 | **Depends on**: ['task_02'] | **Timeout**: 60s
Step 1: Verify niche_score ≥ 7.0. If not, surface for human review before locking.
Step 2: Verify pain_confirmation_rate ≥ 40% from validation conversations.
Step 3: Verify only ONE niche is selected — reject if artifact_01 contains multiple niches as equally ranked.
Step 4: Score guardrails and output to artifact_03.
**Output**: artifact_03 (json)

### Task task_04: Log Niche Decision to Supabase
**Agent**: agent_04 | **Depends on**: ['task_03'] | **Timeout**: 60s
Step 1: Write niche selection record to Supabase: niche, composite_score, pain_confirmation_rate, decision_date, lock_date (30 days from today).
Step 2: Write niche lock reminder to Notion: 'Niche locked until [lock_date]. Do not evaluate other niches until this date.'
Step 3: Log metrics to workflow_metrics table. Output record ID to artifact_04.
Step 4: Set a calendar reminder (via Notion) to review niche performance on lock_date. Reminder text: 'Niche review — evaluate if pivot is justified by outreach data.'
Step 5: Output Supabase record ID to artifact_04 confirming lock is active.
**Output**: artifact_04 (json)

## Guardrail Checklist

### ✅ Must be TRUE:
- [ ] All 3 scoring axes used: artifact_01 contains deal_size, pain_intensity, tech_readiness scores for each niche
- [ ] Validation conversations completed: artifact_02 contains ≥5 outreach attempts and ≥1 actual conversation
- [ ] Personal fit filter applied: selected niche is not one where agent has zero credibility or connections
- [ ] Niche locked for 30 days: artifact_04 contains lock_date = today + 30 days

### ❌ Must be FALSE:
- [ ] No niche scatter: artifact_01 selects exactly ONE niche — not a shortlist of 3 to 'try'
- [ ] No validation skipped: niche not locked before task_02 (validation conversations) completes
- [ ] No low-pain niche locked: pain_confirmation_rate must be ≥40% — niche not locked if below threshold without human override
- [ ] No premature pivot: no niche change triggered within 30-day lock period without guardrail override and documented reason

**Violation policy**: score — compute health score, present to human for decision.

## Monitoring
- Cron: `0 8 * * 1`
- Metrics: Supabase `workflow_metrics` table
- Alerts: GitHub Issues