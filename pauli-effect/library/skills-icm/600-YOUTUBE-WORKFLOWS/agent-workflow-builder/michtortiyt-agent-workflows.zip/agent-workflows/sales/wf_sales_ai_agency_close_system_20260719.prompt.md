# AI Agency Sales Closing System (Michele Torti Method)

**Category**: sales | **Version**: 1.0.0 | **Source**: @michtortiyt (7 videos)

## Goal
Execute a structured AI agency sales call that closes 20%+ of qualified prospects on boring AI offers ($2K–$9.5K) by leading with business pain, not technology.

**Success when**:
- Discovery phase surfaces the prospect's #1 manual pain point with a time or money cost attached
- Proposal uses ROI framing, not feature list
- Offer presented is from the pre-approved boring offers list (appointment setter, reactivation, intake bot, support agent)
- Close attempted within 30-minute call window
- Outcome logged to Supabase with deal stage and objection type

**KPIs**:
- call_to_close_rate: 20 percent
- average_deal_size: 4000 USD
- call_duration: 30 minutes
- objection_resolution_rate: 60 percent

## Agents

### Sales Call Orchestrator (orchestrator)
Tools: supabase, notion

### Pre-Call Researcher (executor)
Tools: bright_data_mcp, supabase

### Call Script Generator (executor)
Tools: supabase

### Offer Compliance Checker (guardian)
Tools: supabase

### CRM Logger (reporter)
Tools: supabase, notion

## Task Execution Order

### Task task_01: Pre-Call Research
**Agent**: agent_02 | **Depends on**: none | **Timeout**: 180s
Step 1: Look up the prospect's business website and LinkedIn. Identify their primary service, approximate team size, and any visible pain points (slow response times, manual booking, no follow-up visible).
Step 2: Identify which of the 4 boring offers best matches their pain: (A) appointment setter, (B) lead reactivation campaign, (C) intake form + CRM auto-populate, (D) customer support AI agent.
Step 3: Find or construct a relevant case study from your portfolio — must be same niche or same pain type. If none exists, prepare a hypothetical ROI scenario with real numbers.
Step 4: Calculate ROI estimate: (average client value to them) × (estimated leads recovered or time saved per month) = monthly ROI. Minimum viable ROI to proceed = 3× the proposed fee.
Step 5: Write pain hypothesis in one sentence: 'I suspect [prospect] is losing [X hours/leads/revenue] per month because [specific manual process].' Write this to artifact_01.
**Output**: artifact_01 (json)

### Task task_02: Generate Call Script
**Agent**: agent_03 | **Depends on**: ['task_01'] | **Timeout**: 120s
Step 1: Write 5 discovery questions that surface pain without pitching. Format: open-ended, business-outcome focused. Example: 'Walk me through what happens when a new lead comes in right now — from inquiry to first appointment.'
Step 2: Write the ROI pivot script (triggered after pain is confirmed): 'So if I understand correctly, you're losing [X] per month from [pain]. What if we could cut that by 80% in 30 days — what would that be worth to you?'
Step 3: Write objection responses for the 3 most common objections: (A) 'We already have someone doing this' → 'Great — what's their close rate on new leads?', (B) 'I need to think about it' → 'What specifically would make this a clear yes for you?', (C) 'It's too expensive' → present middle-tier option at 60% of original price.
Step 4: Write close script: 'Based on what you've told me, I think [offer name] is the right fit. It's [price]. We can start [date]. Does that work?' — no hedging, direct ask.
Step 5: Output all as structured JSON to artifact_02.
**Output**: artifact_02 (json)

### Task task_03: Offer Compliance Check
**Agent**: agent_04 | **Depends on**: ['task_02'] | **Timeout**: 60s
Step 1: Verify proposed offer is on the approved boring offers list. Reject any offer that requires explaining AI technology to the client for more than 60 seconds.
Step 2: Verify the call script uses business outcome language, not tool/tech language. Flag any mention of 'n8n', 'Make.com', 'Claude', 'GPT', 'LLM', 'automation' in the client-facing script.
Step 3: Verify ROI claim is defensible — ratio must be ≥3× fee. If not, flag ng_roi_overpromise.
Step 4: Score all guardrails and compute guardrail_health. Output to artifact_03.
Step 5: If any negative guardrail fires, record violation with weight and present to human for review — do not block.
**Output**: artifact_03 (json)

### Task task_04: Log Outcome to CRM
**Agent**: agent_05 | **Depends on**: ['task_03'] | **Timeout**: 60s
Step 1: Write call outcome record to Supabase workflow_metrics table: prospect_name, niche, deal_stage (closed/follow-up/no-fit), deal_size (if closed), objections_heard, guardrail_health.
Step 2: If deal_stage == 'follow-up': schedule follow-up task in Notion for +3 days with subject 'Send case study to [prospect]'.
Step 3: If deal_stage == 'closed': trigger onboarding checklist creation in Notion.
Step 4: Update call-to-close rate metric in Supabase. If rate drops below 15% over last 10 calls, flag improvement suggestion: 'Review discovery question quality — pain not being surfaced.'
Step 5: Output CRM record ID to artifact_04.
**Output**: artifact_04 (json)

## Guardrail Checklist

### ✅ Must be TRUE:
- [ ] Pain confirmed before pitch: task_02 discovery questions are answered before ROI script triggers
- [ ] Offer on approved boring list: proposed offer is one of: appointment setter, reactivation, intake bot, support agent
- [ ] ROI ≥ 3× fee: artifact_01 roi_estimate ≥ 3 × proposed_fee
- [ ] Outcome logged: artifact_04 contains non-null crm_record_id

### ❌ Must be FALSE:
- [ ] No tech jargon in client script: client-facing script contains zero tool names (n8n, Make, Claude, GPT, LLM)
- [ ] No ROI overpromise: no claim of results in under 7 days or ROI above 10× without verified proof
- [ ] No unapproved offer: no complex custom-build offer proposed on first call without discovery first
- [ ] No empty CRM record: artifact_04 is not null and contains deal_stage field

**Violation policy**: score — compute health score, present to human for decision.

## Monitoring
- Cron: `0 8 * * 1`
- Metrics: Supabase `workflow_metrics` table
- Alerts: GitHub Issues