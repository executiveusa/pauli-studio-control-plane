# AI Agency 30-Day First Client Acquisition System

**Category**: lead_gen | **Version**: 1.0.0 | **Source**: @michtortiyt (2 videos)

## Goal
Acquire first AI agency client within 30 days using outbound LinkedIn DM + cold email combo, targeting service businesses in top 3 niches, with 50 outreach messages per day achieving ≥3 booked calls per week.

**Success when**:
- ICP defined with niche, company size, and job title before Day 8
- Outreach message written and tested by Day 10
- 50 personalized outreach messages sent per day from Day 11 onwards
- ≥3 discovery calls booked per week
- First signed client with deposit received by Day 30

**KPIs**:
- daily_outreach_volume: 50 messages
- connection_acceptance_rate: 30 percent
- reply_rate: 10 percent
- call_booking_rate: 3 calls_per_week
- days_to_first_client: 30 days

## Agents

### 30-Day Campaign Orchestrator (orchestrator)
Tools: supabase, notion

### ICP & Prospect List Builder (executor)
Tools: bright_data_mcp, supabase

### Outreach Copywriter (executor)
Tools: supabase

### Message Compliance Checker (guardian)
Tools: supabase

### Outreach Metrics Tracker (reporter)
Tools: supabase

## Task Execution Order

### Task task_01: Define ICP and Select Niche
**Agent**: agent_02 | **Depends on**: none | **Timeout**: 240s
Step 1: Choose ONE niche from the approved beginner list: dental clinics, real estate agents, mortgage brokers, med spas, law firms. Selection criteria: pick the one you have the most credibility or connections in.
Step 2: Define ICP — 3 required fields: (a) business type within niche, (b) geography (city or region), (c) company size (1-10 employees is easiest for first client).
Step 3: Identify the #1 pain point for this ICP that your boring offer solves. Write as: '[ICP type] lose [X hours/leads] per week because [specific manual process]. Your solution: [offer name] that automates this in [timeframe].'
Step 4: Build initial prospect list of 200 contacts from LinkedIn using ICP filters. Export to Supabase prospect table with fields: name, company, LinkedIn URL, niche, status=new.
Step 5: Write ICP profile to artifact_01.
**Output**: artifact_01 (json)

### Task task_02: Write Outreach Sequences
**Agent**: agent_03 | **Depends on**: ['task_01'] | **Timeout**: 120s
Step 1: Write LinkedIn connection request note — max 200 characters, no pitch, reference something specific about their business. Example: 'Hey [name], noticed you run [clinic name] in [city]. I work with [niche] businesses — would love to connect.'
Step 2: Write LinkedIn DM sequence — 3 messages: (a) Day 0 value opener (share insight relevant to their niche, no ask), (b) Day 3 case study DM (one sentence outcome + 'happy to share the breakdown'), (c) Day 7 final bump ('Following up one last time — if timing is better later, just reply and I'll reach back out.').
Step 3: Write cold email — subject line: under 8 words, specific to niche, no exclamation mark. Body: 3 lines max. Line 1 = hook (pain or outcome). Line 2 = proof (case study sentence with number). Line 3 = CTA ('Worth a 15-min call this week?'). P.S. = one social proof line.
Step 4: Write follow-up email for Day 4 and Day 10.
Step 5: Output all copy to artifact_02.
**Output**: artifact_02 (json)

### Task task_03: Compliance and Spam Check
**Agent**: agent_04 | **Depends on**: ['task_02'] | **Timeout**: 60s
Step 1: Check LinkedIn connection note is under 200 characters and contains no pitch.
Step 2: Check cold email body is 3 lines or under, contains no tool names, no exclamation marks in subject, no 'FREE' or 'LIMITED TIME'.
Step 3: Check that all 3 DMs are personalization-ready (contain [name] and [niche] placeholders).
Step 4: Verify Day 7 DM is a genuine break-up message and not a disguised pitch.
Step 5: Score guardrails and output to artifact_03.
**Output**: artifact_03 (json)

### Task task_04: Daily Outreach Execution and Tracking
**Agent**: agent_05 | **Depends on**: ['task_03'] | **Timeout**: 60s
Step 1: Each day, pull next 50 prospects from Supabase prospect table where status=new. Update status to 'outreach_sent' after sending.
Step 2: Log daily stats to Supabase: date, messages_sent, connections_accepted, replies_received, calls_booked.
Step 3: Compute daily conversion rates: acceptance_rate = connections_accepted/sent, reply_rate = replies/accepted, booking_rate = calls_booked/replies.
Step 4: If acceptance_rate < 20% after 3 days: flag ng_low_acceptance — connection note needs rewrite.
Step 5: If reply_rate < 5% after 5 days: flag ng_low_reply — DM sequence message 1 needs rewrite. Output flags to artifact_04.
**Output**: artifact_04 (json)

## Guardrail Checklist

### ✅ Must be TRUE:
- [ ] Single niche selected: artifact_01 contains exactly one niche — not a list
- [ ] Cold email under 3 lines: artifact_02 cold_email body contains 3 lines or fewer before P.S.
- [ ] 50 messages sent daily: artifact_04 messages_sent == 50 for each active campaign day
- [ ] Metrics logged daily: Supabase workflow_metrics has entry for each campaign day

### ❌ Must be FALSE:
- [ ] No pitch in connection request: LinkedIn connection note contains no offer, price, or service mention
- [ ] No spam trigger words: Subject line contains no: FREE, LIMITED, EXCLUSIVE, !!!, URGENT, GUARANTEED
- [ ] No multi-niche scatter: prospect_list contains only one niche — no mixing niches in same sequence
- [ ] No channel switching before 30 days: campaign stays on LinkedIn+email combo for full 30 days — no pivot to cold calling or paid ads

**Violation policy**: score — compute health score, present to human for decision.

## Monitoring
- Cron: `0 9 * * *`
- Metrics: Supabase `workflow_metrics` table
- Alerts: GitHub Issues