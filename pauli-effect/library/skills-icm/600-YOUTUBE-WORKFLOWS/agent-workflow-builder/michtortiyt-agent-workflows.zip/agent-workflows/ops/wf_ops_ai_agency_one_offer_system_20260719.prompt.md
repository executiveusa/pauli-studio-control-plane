# AI Agency Operations: One Offer, One Channel, One Delivery SOP

**Category**: ops | **Version**: 1.0.0 | **Source**: @michtortiyt (4 videos)

## Goal
Implement the Michele Torti one-offer-one-channel-one-SOP operating system for an AI agency to reach $10K/mo without adding complexity, by defining a single core offer, locking one acquisition channel, and building a repeatable delivery checklist.

**Success when**:
- Agency has exactly ONE clearly defined core offer with a fixed price
- Agency is active on exactly ONE acquisition channel only
- A written delivery SOP exists with step-by-step checklist for every client onboarding
- Weekly metrics reviewed: outreach-to-call rate and call-to-close rate
- No new tool or channel added without passing the 'sign clients or deliver faster' test

**KPIs**:
- active_offers: 1 count
- active_channels: 1 count
- delivery_sop_completeness: 100 percent
- weekly_outreach_to_call_rate: 5 percent
- monthly_recurring_revenue: 10000 USD

## Agents

### Agency Ops Auditor (orchestrator)
Tools: supabase, notion

### Offer Simplifier (executor)
Tools: supabase

### SOP Builder (executor)
Tools: notion, supabase

### Complexity Guardian (guardian)
Tools: supabase

### Weekly Metrics Reviewer (reporter)
Tools: supabase

## Task Execution Order

### Task task_01: Agency Audit — Identify Complexity
**Agent**: agent_01 | **Depends on**: none | **Timeout**: 120s
Step 1: List all current services the agency offers. Count them. If count > 1, flag ng_multiple_offers.
Step 2: List all acquisition channels currently active (LinkedIn, cold email, cold call, paid ads, content, referrals). Count them. If count > 1, flag ng_multiple_channels.
Step 3: Check if a written delivery SOP exists. If not, flag ng_no_sop.
Step 4: Check if weekly metrics are being tracked (outreach-to-call rate, call-to-close rate). If not, flag ng_no_metrics.
Step 5: Compute complexity score: (offers - 1) × 0.30 + (channels - 1) × 0.30 + (no_sop ? 0.25 : 0) + (no_metrics ? 0.15 : 0). Higher = more broken. Output to artifact_01.
**Output**: artifact_01 (json)

### Task task_02: Define Single Core Offer
**Agent**: agent_02 | **Depends on**: ['task_01'] | **Timeout**: 120s
Step 1: Select ONE offer from the boring offers list that best matches current client base and niche. Write it as: '[Offer name]: [one sentence business outcome description]. Price: $[amount]. Delivery time: [X] weeks.'
Step 2: Create 3-tier pricing: Bronze (minimum scope, 60% of core price), Silver (core offer, 100%), Gold (core + retention/support, 150%). Present Gold first in all sales conversations.
Step 3: Write the offer positioning statement: 'We build [outcome] for [niche] businesses. Most of our clients see [specific result] within [timeframe].'
Step 4: Archive all other service descriptions. Mark them inactive in Notion.
Step 5: Output core offer definition to artifact_02.
**Output**: artifact_02 (json)

### Task task_03: Build Delivery SOP
**Agent**: agent_03 | **Depends on**: ['task_02'] | **Timeout**: 180s
Step 1: Write client onboarding checklist — 10-step maximum: (1) deposit collected, (2) onboarding call scheduled, (3) access credentials gathered, (4) project scope confirmed in writing, (5) delivery timeline shared, (6) first check-in scheduled, (7-10) delivery milestones).
Step 2: Write delivery SOP for the core offer — every step from 'project start' to 'client sign-off'. Include: who does each step, what tool is used, what the output looks like, and how long it takes.
Step 3: Write weekly client check-in template: 5 bullet points max. (1) What was done this week, (2) What's next, (3) Any blockers, (4) Metric update, (5) One question for client.
Step 4: Write QA checklist — things to verify before delivering any output to client.
Step 5: Output all SOPs to artifact_03 and write to Notion.
**Output**: artifact_03 (json)

### Task task_04: Weekly KPI Review
**Agent**: agent_05 | **Depends on**: ['task_03'] | **Timeout**: 60s
Step 1: Every Monday, pull last 7 days of metrics from Supabase: outreach_sent, calls_booked, deals_closed, mrr_total.
Step 2: Compute outreach-to-call rate and call-to-close rate. Compare to prior week.
Step 3: If outreach-to-call < 5%: flag 'fix outreach message — not generating interest'. If call-to-close < 20%: flag 'fix offer clarity or discovery questions'.
Step 4: Evaluate any new tool or channel proposed this week against the test: 'Does this help me sign more clients or deliver faster?' If neither: log as 'rejected — shiny object' in Supabase.
Step 5: Write weekly verdict to artifact_04: GREEN (both rates healthy), YELLOW (one rate declining), RED (both rates declining — stop and audit).
**Output**: artifact_04 (json)

## Guardrail Checklist

### ✅ Must be TRUE:
- [ ] Single offer confirmed: artifact_02 core_offer is a single object with one name, one price, one outcome
- [ ] SOP has onboarding checklist: artifact_03 onboarding_checklist has 5-10 steps
- [ ] Weekly metrics reviewed: artifact_04 written every Monday with GREEN/YELLOW/RED verdict
- [ ] Tool test applied: Every proposed new tool evaluated against 'sign clients or deliver faster' test and outcome logged

### ❌ Must be FALSE:
- [ ] No multiple offers: artifact_02 does not contain more than one primary offer
- [ ] No channel pivot before 30 days: workflow does not switch acquisition channel within first 30 days of campaign
- [ ] No unevaluated new tools: no new tool appears in delivery SOP without passing the sign-clients-or-deliver-faster test
- [ ] No skipped QA: QA checklist completed before every client delivery — no artifact delivered without QA artifact

**Violation policy**: score — compute health score, present to human for decision.

## Monitoring
- Cron: `0 8 * * 1`
- Metrics: Supabase `workflow_metrics` table
- Alerts: GitHub Issues